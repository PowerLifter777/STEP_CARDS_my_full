import './components/header/index.js';
import './components/main/index.js';
import * as flsFunctions from "./tools/functions.js";

flsFunctions.isWebp();