export let configFTP = {
    host: "", //ip ftp server
    user: "", // user
    password: "", //pass
    parallel: 5 // pipe in time
}